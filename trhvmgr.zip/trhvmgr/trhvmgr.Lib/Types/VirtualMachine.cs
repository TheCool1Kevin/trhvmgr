﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core.Types
{
    public class VirtualMachine
    {
        public Guid VmId { get; set; }
        public Guid VmParent { get; set; }
        public string HostName { get; set; }
        public string VmName { get; set; }
        public VmState State { get; set; }
        public int Type { get; set; }
    }

    public enum VmState
    {
        Invalid = 0, // Default
        Other,
        Running,
        Off,
        Stopping,
        Saved,
        Paused,
        Starting,
        Reset,
        Saving,
        Pausing,
        Resuming,
        FastSaved,
        FastSaving,
        RunningCritical,
        OffCritical,
        StoppingCritical,
        SavedCritical,
        PausedCritical,
        StartingCritical,
        ResetCritical,
        SavingCritical,
        PausingCritical,
        ResumingCritical,
        FastSavedCritical,
        FastSavingCritical
    }
}
