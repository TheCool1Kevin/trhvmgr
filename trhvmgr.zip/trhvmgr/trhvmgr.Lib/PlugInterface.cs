﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Topology;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using trhvmgr.Core;
using trhvmgr.Core.Types;

namespace trhvmgr.Core
{
    public static class PlugInterface
    {
        private static Assembly assembly;
        private static Type type;
        private static Action<string> ee;
        private static Action<string> ww;

        #region Constructor

        public static void Init(string dllPath, Action<string> e, Action<string> w)
        {
            assembly = Assembly.LoadFile(dllPath);
            type = assembly.GetType("trhvmgr.Plugs.MainInterface");
            ee = e;
            ww = w;
        }

        public static void UpdateCred()
        {
            type.GetMethod("Init", new Type[] { typeof(Action<string>), typeof(Action<string>), typeof(PSCredential) })
                    .Invoke(null, new object[] { ee, ww, SessionState.Instance.PSCredential });
        }

        public static void BringOnline(string hostName)
        {
            using (PowerShell ps = PowerShell.Create())
            {
                var ret = ps.AddCommand("New-PSSession").AddParameter("ComputerName", hostName).AddParameter("Credential", SessionState.Instance.PSCredential).Invoke();
                ps.AddCommand("Remove-PSSession").AddParameter("Confirm").AddParameter("Session", ret).Invoke();
            }
        }

        #endregion

        #region Virtual Machine Creation/Destruction

        public static void CreateVm(string vmName, string hostName)
        {
            Guid vmid = (Guid)type.GetMethod("CreateVm", new Type[] { typeof(string), typeof(string) })
                    .Invoke(null, new object[] { vmName, hostName });
            SessionState.Instance.Client.AddVm(new Database.VirtualMachineObject
            {
                Self = vmid,
                Parent = new Guid(vmName),
                Type = 1
            });
        }

        public static void DeleteVm(VirtualMachine[] vms)
        {
            foreach(var v in vms)
                type.GetMethod("DeleteVm", new Type[] { typeof(string), typeof(string) })
                    .Invoke(null, new object[] { v.VmId.ToString(), v.HostName });
        }

        #endregion

        #region Virtual Machine State Control

        public static void StartVm(VirtualMachine[] vms)
        {
            foreach(var v in vms)
                type.GetMethod("StartVm", new Type[] { typeof(string), typeof(string) })
                    .Invoke(null, new object[] { v.VmId.ToString(), v.HostName });
        }

        public static void StopVm(VirtualMachine[] vms)
        {
            foreach (var v in vms)
                type.GetMethod("StopVm", new Type[] { typeof(string), typeof(string) })
                    .Invoke(null, new object[] { v.VmId.ToString(), v.HostName });
        }

        public static void ResumeVm(VirtualMachine[] vms)
        {
            foreach (var v in vms)
                type.GetMethod("ResumeVm", new Type[] { typeof(string), typeof(string) })
                    .Invoke(null, new object[] { v.VmId.ToString(), v.HostName });
        }

        public static void RestartVm(VirtualMachine[] vms)
        {
            foreach (var v in vms)
                type.GetMethod("RestartVm", new Type[] { typeof(string), typeof(string) })
                    .Invoke(null, new object[] { v.VmId.ToString(), v.HostName });
        }

        public static void SuspendVm(VirtualMachine[] vms)
        {
            foreach (var v in vms)
                type.GetMethod("SuspendVm", new Type[] { typeof(string), typeof(string) })
                    .Invoke(null, new object[] { v.VmId.ToString(), v.HostName });
        }

        #endregion

        #region Virtual Machine State Query

        public static List<VirtualMachine> GetVms(string hostName)
        {
            List<VirtualMachine> vms = new List<VirtualMachine>();
            // Go, go, go!
            MethodInfo m = type.GetMethod("GetVms", new Type[] { typeof(string) });
            List<PSObject> ret = m.Invoke(null, new object[] { hostName }) as List<PSObject>;
            if (ret == null) return vms;
            // Convert psobject to virtualmachine
            foreach (var r in ret)
            {
                if (!Enum.TryParse((string)r.Members["State"].Value, out VmState s))
                    s = VmState.Invalid;
                vms.Add(new VirtualMachine
                {
                    VmId = (Guid)r.Members["VmId"].Value,
                    VmName = (string)r.Members["Name"].Value,
                    State = s,
                    HostName = hostName,
                    Type = SessionState.Instance.Client.GetVmIndex(((Guid) r.Members["VmId"].Value).ToString())
                });
            }
            return vms;
        }

        #endregion

        #region Machine State Control

        public static void RestartServer(List<Server> servers)
        {
            foreach (var s in servers)
                if(s != null)
                    type.GetMethod("RestartServer", new Type[] { typeof(string) })
                        .Invoke(null, new object[] { s.HostName });
        }

        public static void StartServer(List<Server> servers)
        {
            foreach (var s in servers)
                if (s != null)
                    type.GetMethod("StartServer", new Type[] { typeof(IPAddress), typeof(PhysicalAddress) })
                        .Invoke(null, new object[] { s.IpAddress, s.MacAddress });
        }

        public static void StopServer(List<Server> servers)
        {
            foreach (var s in servers)
                if (s != null)
                    type.GetMethod("StopServer", new Type[] { typeof(string) })
                        .Invoke(null, new object[] { s.HostName });
        }

        public static void SetMacRange(Server server)
        {
            type.GetMethod("SetMacRange", new Type[] { typeof(string), typeof(long), typeof(long) })
                .Invoke(null, new object[]
                {
                    server.HostName,
                    server.MacBegin, server.MacEnd,
                    SessionState.Instance.PSCredential
                });
        }

        public static void ConfigureServer(Server server)
        {
            type.GetMethod("ConfigureServer", new Type[] { typeof(string) })
                .Invoke(null, new object[] { server.HostName });
        }

        #endregion
    }
}
