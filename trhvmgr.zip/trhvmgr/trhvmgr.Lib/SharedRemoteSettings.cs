﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core
{
    /// <summary>
    /// Class to describe remote settings that are shared
    /// </summary>
    public class SharedRemoteSettings : MarshalByRefObject
    {
    }
}
