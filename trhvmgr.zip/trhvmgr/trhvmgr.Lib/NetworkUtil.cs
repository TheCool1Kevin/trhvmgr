﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core
{
    /// <summary>
    /// Since this is a Utility class, there's a lot of copied code.
    /// Why reinvent the wheel? :-)
    /// </summary>
    public static class NetworkUtil
    {
        [Obsolete("Use the WoL bundled with the WakeOnLAN NuGet package instead.")]
        public static int DoWoL(string ip, string MacAddress)
        {
            WOLClass client = new WOLClass();
            client.Connect(IPAddress.Parse(ip), 0);
            //client.SetClientToBrodcastMode();
            int counter = 0;
            byte[] bytes = new byte[1024];
            for (int y = 0; y < 6; y++)
                bytes[counter++] = 0xFF;
            for (int y = 0; y < 16; y++)
                for (int z = 0, i = 0; z < 6; z++, i += 2)
                    bytes[counter++] = byte.Parse(MacAddress.Substring(i, 2), NumberStyles.HexNumber);
            int ret = client.Send(bytes, 1024);
            client.Close();
            return ret;
        }

        public static string GetMacByIP(string ipAddress)
        {
            // Grab all online interfaces
            var query = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n =>
                    n.OperationalStatus == OperationalStatus.Up && // Only grabbing what's online
                    n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                .Select(_ => new
                {
                    PhysicalAddress = _.GetPhysicalAddress(),
                    IPProperties = _.GetIPProperties(),
                });

            // Grab the first interface that has a unicast address that matches your search string
            var mac = query
                .Where(q => q.IPProperties.UnicastAddresses
                    .Any(ua => ua.Address.ToString() == ipAddress))
                .FirstOrDefault()
                .PhysicalAddress;

            // Return the mac address with formatting (eg "00-00-00-00-00-00")
            return string.Join("-", mac.GetAddressBytes().Select(b => b.ToString("X2")));
        }

        // We derive our class from a standard one
        public class WOLClass : UdpClient
        {
            public WOLClass() : base() { }
            // This is needed to send broadcast packet
            public void SetClientToBrodcastMode()
            {
                if (this.Active) this.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 0);
            }
        }
    }
}
