﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Text;
using System.Threading.Tasks;
using trhvmgr.Core;
using trhvmgr.Core.Types;

namespace trhvmgr.Core
{
    /// <summary>
    /// This singleton instance provides global information about the
    /// programs state, to be accessed by everyone.
    /// </summary>
    public class SessionState
    {
        // Singleton pattern using .NET 4's Lazy (this is the best way)
        private static readonly Lazy<SessionState> lazy = new Lazy<SessionState>(() => new SessionState());
        public static SessionState Instance { get { return lazy.Value; } }

        public Controller Controller { get; private set; }
        //public Dictionary<string, Server> ServersList { get; private set; }
        //public List<Guid> VirtualMachines { get; private set; }
        //public List<Guid> BaseVMs { get; private set; }
        //public List<Guid> TemplateVMs { get; private set; }
        private PSCredential pscred = null;
        public PSCredential PSCredential
        {
            get { return pscred; }
            set
            {
                pscred = value;
                PlugInterface.UpdateCred();
            }
        }
        public bool IsAlive { get; private set; }
        public ServerClient Client { get; private set; }

        private bool init = false;

        private SessionState()
        {
            //ServersList = new Dictionary<string, Server>();
            //VirtualMachines = new List<Guid>();
            //BaseVMs = new List<Guid>();
            //TemplateVMs = new List<Guid>();
        }

        public void InitializeFields(string ctrlHost, PSCredential cred)
        {
            if (init) return;
            init = true;
            this.PSCredential = cred;
            Client = new ServerClient();

            // Obtain controller information
            Controller = new Controller(ctrlHost);
            IsAlive = true;
        }
    }
}
