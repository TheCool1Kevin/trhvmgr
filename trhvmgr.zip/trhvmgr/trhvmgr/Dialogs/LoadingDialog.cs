﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management.Automation;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Topology;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using trhvmgr.Core;
using trhvmgr.Properties;

namespace trhvmgr.Dialogs
{
    public partial class LoadingDialog : Form
    {
        #region Global Variables

        private bool ok = false;
        private string server;
        private PSCredential cred;
        public string MacAddress { get; private set; }
        public string IpAddress { get; private set; }
        private readonly string[] messages = {
            "Resolving DNS hostname...",
            "Retrieving subnet and broadcast mask...",
            "Getting MAC Address...",
            "Pinging server status...",
            "",
            "Retrieving controller information...",
            "Done!"
        };
        private readonly int maximumSteps;

        #endregion

        #region Constructor

        public LoadingDialog(string controllerServer, PSCredential c)
        {
            maximumSteps = messages.Length;
            server = controllerServer;
            cred = c;
            MacAddress = Properties.Settings.Default.ControllerMac;
            IpAddress = Properties.Settings.Default.ControllerIp;
            InitializeComponent();
        }

        #endregion

        #region Form Events

        private void LoadingDialog_LoadShownWhatever(object sender, EventArgs e)
        {
            progressBar1.Maximum = this.maximumSteps;
            Task t = Task.Run((Action)LoadEverything);
            t.GetAwaiter().OnCompleted(() =>
            {
                this.DialogResult = ok ? DialogResult.OK : DialogResult.Abort;
            });
        }

        #endregion

        #region Private Methods

        private void LoadEverything()
        {
            Thread.Sleep(100);
            // Try to get the IP address
            UpdateProgress();
            IPAddress ip = null;
            try
            {
                // Increment status
                IPHostEntry hostEntry = Dns.GetHostEntry(server);
                ip = hostEntry.AddressList[0];
            } catch (Exception) {
                // Is it already in the settings? If so, we can assume it's valid
                if (string.IsNullOrEmpty(IpAddress)) { ErrorAction("Cannot resolve hostname."); return; }
                IPAddress.TryParse(IpAddress, out ip);
            }

            // Get Subnet broadcast IP
            UpdateProgress();
            var mask = new NetMask(255, 255, 255, 0);
            int cidr = mask.Cidr;
            var networkPrefix = ip & mask; // Bitwise and to mask the IP
            networkPrefix = ip.GetNetworkPrefix(mask);
            IPAddress broadcastAddress = ip.GetBroadcastAddress(mask);

            // Try to get MAC address
            UpdateProgress();
            try
            {
                MacAddress = ArpRequest.Send(ip).Address.ToString();
            } catch (Exception) {
                // Did we have a MAC address specified already? If not, fail.
                if (string.IsNullOrEmpty(MacAddress)) return;
            }
            // Normalize address
            MacAddress = Regex.Replace(MacAddress, @"[^0-9A-Fa-f]", "");
            Settings.Default.ControllerMac = MacAddress;
            Settings.Default.Save();

            // Is the server online?
            PingReply reply = null;
            try
            {
                UpdateProgress();
                Ping ping = new Ping();
                reply = ping.Send(ip, 2000 /* timeout = 2 seconds */);
                UpdateProgress();
                if (reply.Status != IPStatus.Success)
                {
                    for(int i = 0; i < 5; i++)
                    {
                        WriteStatus($"Attempting WoL {i + 1}/5...");
                        // Go, go, go!
                        new IPEndPoint(broadcastAddress, 0).SendWol(PhysicalAddress.Parse(MacAddress));
                        reply = ping.Send(ip, 10000 + i * 4); // 10 - 30 second incremental timeout
                        if (reply.Status == IPStatus.Success) break;
                        WriteStatus("WoL Successful!");
                    }
                    if (reply.Status != IPStatus.Success) throw new Exception("Host unreachable. WoL failed.");
                }
            }
            catch (Exception e) { ErrorAction(e.Message); return; }

            if (reply.Status != IPStatus.Success)
                return;

            // Load the controller server
            // TODO: Use custom securestring textbox
            UpdateProgress();
            try
            {
                Core.SessionState.Instance.InitializeFields(this.server, cred);
            } catch(Exception e)
            {
                MessageBox.Show(e.Message, "Server connection failed.");
                return;
            }

            // Done!
            UpdateProgress();
            ok = true;
        }

        private void ErrorAction(string msg)
        {
            MessageBox.Show(msg);
        }

        /// <summary>
        /// Call this right before you start an action.
        /// </summary>
        private void UpdateProgress()
        {
            // Has been called from a "wrong" thread?
            if (InvokeRequired)
            {
                // Dispatch to correct thread, use BeginInvoke if you don't need
                // caller thread until operation completes
                Invoke(new MethodInvoker(UpdateProgress));
            }
            else
            {
                WriteStatus(messages[progressBar1.Value]);
                progressBar1.PerformStep();
                Thread.Sleep(100);
            }
        }

        private void WriteStatus(string s)
        {
            // Has been called from a "wrong" thread?
            if (InvokeRequired)
            {
                // Dispatch to correct thread, use BeginInvoke if you don't need
                // caller thread until operation completes
                Invoke((MethodInvoker) delegate { WriteStatus(s); });
            }
            else
            {
                statusLabel.Text = s;
            }
        }

        #endregion
    }
}
