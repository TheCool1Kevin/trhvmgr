﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using trhvmgr.Core;
using trhvmgr.Core.Types;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr
{
    public partial class VmsList : ActionDock
    {
        #region Constructor

        public VmsList() : base()
        {
            // Create all the categories
            ActionCategories[0] = "VM Operations";
            // Create all the actions
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Connect",
                Action = () => {
                    VmConnect win = new VmConnect(GetSelectedVms()[0].HostName, GetSelectedVms()[0].VmId.ToString(), GetSelectedVms()[0].VmName, true);
                    win.Show(MainWindow.Instance.panel, DockState.Document);
                },
                Category = 0
            });
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Start",
                Action = () => {
                    ((MainFrm)MainWindow.Instance).StatusText = "Starting virtual machines...";
                    PlugInterface.StartVm(GetSelectedVms().ToArray()); RefreshListAsync();
                },
                Category = 0
            });
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Stop",
                Action = () => {
                    ((MainFrm)MainWindow.Instance).StatusText = "Stopping virtual machines...";
                    PlugInterface.StopVm(GetSelectedVms().ToArray()); RefreshListAsync();
                },
                Category = 0
            });
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Suspend",
                Action = () => {
                    ((MainFrm)MainWindow.Instance).StatusText = "Suspending virtual machines...";
                    PlugInterface.SuspendVm(GetSelectedVms().ToArray()); RefreshListAsync();
                },
                Category = 0
            });
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Resume",
                Action = () => {
                    ((MainFrm)MainWindow.Instance).StatusText = "Resuming virtual machines...";
                    PlugInterface.ResumeVm(GetSelectedVms().ToArray()); RefreshListAsync();
                },
                Category = 0
            });
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Delete",
                Action = () => {
                    ((MainFrm)MainWindow.Instance).StatusText = "Deleting virtual machines...";
                    PlugInterface.DeleteVm(GetSelectedVms().ToArray()); RefreshListAsync();
                },
                Category = 0
            });
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Set as Base",
                Action = () => {
                    foreach (var v in GetSelectedVms())
                        SessionState.Instance.Client.AddVm(new Core.Database.VirtualMachineObject
                        {
                            Self = v.VmId,
                            Parent = v.VmParent,
                            Type = 2
                        });
                    RefreshListAsync();
                },
                Category = 0
            });

            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Create Template from Base",
                Action = () => {
                    var v = GetSelectedVms()[0];
                    PlugInterface.CreateVm(v.VmId.ToString(), v.HostName);
                    RefreshListAsync();
                },
                IsVisible = () =>
                {
                    if (GetSelectedVms().Count != 1) return false;
                    if (GetSelectedVms()[0].Type == 2) return true;
                    return false;
                },
                Category = 0
            });

            InitializeComponent();
        }

        #endregion

        #region Events

        private void VmsList_Load(object sender, EventArgs e)
        {
            RefreshListAsync();
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            MainWindow.Instance.ReloadActionPane(this);
            this.MarkActionDirty();
        }

        private void listBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (sender != listBox) return;
            if (e.Control && e.KeyCode == Keys.C)
            {
                StringBuilder sb = new StringBuilder();
                foreach (var v in GetSelectedVms())
                    sb.AppendLine(v.VmId.ToString());
                Clipboard.SetText(sb.ToString());
            }
        }

        #endregion

        #region Public Methods

        public void UpdateList(List<VirtualMachine> vms)
        {
            if (InvokeRequired) Invoke((MethodInvoker) delegate { UpdateList(vms); });
            else
            {
                listBox.Items.Clear();
                foreach (var s in vms)
                {
                    ListViewItem i = new ListViewItem();
                    i.Group = listBox.Groups[s.Type];
                    i.Text = s.VmName;
                    i.UseItemStyleForSubItems = false;
                    i.SubItems.Add(s.VmId.ToString()).Font = new Font("Consolas", 9);
                    i.SubItems.Add(s.State.ToString());
                    i.Tag = s;
                    listBox.Items.Add(i);
                }
            }
        }

        public void RefreshListAsync()
        {
            new Task(() =>
            {
                Thread.Sleep(1000);
                RefreshList();
            }).Start();
        }

        public void RefreshList()
        {
            if (InvokeRequired) Invoke((MethodInvoker) RefreshList);
            else
            {
                ((MainFrm)MainWindow.Instance).StatusText = "Reloading virtual machines...";
                SessionState.Instance.Controller.UpdateVmList();
                UpdateList(SessionState.Instance.Controller.VirtualMachines);
                ((MainFrm)MainWindow.Instance).StatusText = "Ready.";
            }
        }

        #endregion

        #region Private Methods

        private List<VirtualMachine> GetSelectedVms()
        {
            List<VirtualMachine> vms = new List<VirtualMachine>();
            foreach (ListViewItem e in listBox.SelectedItems) vms.Add(e.Tag as VirtualMachine);
            return vms;
        }

        #endregion
    }
}
