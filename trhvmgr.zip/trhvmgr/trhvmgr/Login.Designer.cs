﻿namespace trhvmgr
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.hiddenRes = new System.Windows.Forms.Button();
            this.loadingBox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.serverTxt = new System.Windows.Forms.TextBox();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.subBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.changeDomain = new System.Windows.Forms.LinkLabel();
            this.domainLabel = new System.Windows.Forms.Label();
            this.pswTxt = new System.Windows.Forms.MaskedTextBox();
            this.userTxt = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loadingBox)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.hiddenRes);
            this.groupBox1.Controls.Add(this.loadingBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.serverTxt);
            this.groupBox1.Controls.Add(this.cancelBtn);
            this.groupBox1.Controls.Add(this.subBtn);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.changeDomain);
            this.groupBox1.Controls.Add(this.domainLabel);
            this.groupBox1.Controls.Add(this.pswTxt);
            this.groupBox1.Controls.Add(this.userTxt);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(5, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox1.Size = new System.Drawing.Size(296, 173);
            this.groupBox1.TabIndex = 100;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Login as MCA Administrator or Higher";
            // 
            // hiddenRes
            // 
            this.hiddenRes.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.hiddenRes.Enabled = false;
            this.hiddenRes.Location = new System.Drawing.Point(3, 147);
            this.hiddenRes.Name = "hiddenRes";
            this.hiddenRes.Size = new System.Drawing.Size(33, 23);
            this.hiddenRes.TabIndex = 100;
            this.hiddenRes.UseVisualStyleBackColor = true;
            this.hiddenRes.Visible = false;
            // 
            // loadingBox
            // 
            this.loadingBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.loadingBox.Image = global::trhvmgr.Properties.Resources.loading;
            this.loadingBox.ImageLocation = "";
            this.loadingBox.Location = new System.Drawing.Point(263, 101);
            this.loadingBox.Margin = new System.Windows.Forms.Padding(0);
            this.loadingBox.Name = "loadingBox";
            this.loadingBox.Size = new System.Drawing.Size(20, 20);
            this.loadingBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.loadingBox.TabIndex = 14;
            this.loadingBox.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Controller:";
            // 
            // serverTxt
            // 
            this.serverTxt.Location = new System.Drawing.Point(77, 101);
            this.serverTxt.Name = "serverTxt";
            this.serverTxt.Size = new System.Drawing.Size(183, 20);
            this.serverTxt.TabIndex = 6;
            this.serverTxt.TextChanged += new System.EventHandler(this.serverName_TextChanged);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Location = new System.Drawing.Point(208, 136);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 23);
            this.cancelBtn.TabIndex = 8;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // subBtn
            // 
            this.subBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.subBtn.Location = new System.Drawing.Point(127, 136);
            this.subBtn.Name = "subBtn";
            this.subBtn.Size = new System.Drawing.Size(75, 23);
            this.subBtn.TabIndex = 7;
            this.subBtn.Text = "Login";
            this.subBtn.UseVisualStyleBackColor = true;
            this.subBtn.Click += new System.EventHandler(this.subBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Password:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Username:";
            // 
            // changeDomain
            // 
            this.changeDomain.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.changeDomain.AutoSize = true;
            this.changeDomain.Location = new System.Drawing.Point(239, 23);
            this.changeDomain.Name = "changeDomain";
            this.changeDomain.Size = new System.Drawing.Size(44, 13);
            this.changeDomain.TabIndex = 9;
            this.changeDomain.TabStop = true;
            this.changeDomain.Text = "Change";
            this.changeDomain.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.changeDomain_LinkClicked);
            // 
            // domainLabel
            // 
            this.domainLabel.AutoSize = true;
            this.domainLabel.Location = new System.Drawing.Point(13, 23);
            this.domainLabel.Name = "domainLabel";
            this.domainLabel.Size = new System.Drawing.Size(49, 13);
            this.domainLabel.TabIndex = 6;
            this.domainLabel.Text = "Domain: ";
            // 
            // pswTxt
            // 
            this.pswTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pswTxt.AsciiOnly = true;
            this.pswTxt.Location = new System.Drawing.Point(77, 74);
            this.pswTxt.Name = "pswTxt";
            this.pswTxt.Size = new System.Drawing.Size(206, 20);
            this.pswTxt.TabIndex = 5;
            this.pswTxt.UseSystemPasswordChar = true;
            // 
            // userTxt
            // 
            this.userTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.userTxt.Location = new System.Drawing.Point(77, 48);
            this.userTxt.Name = "userTxt";
            this.userTxt.Size = new System.Drawing.Size(206, 20);
            this.userTxt.TabIndex = 4;
            // 
            // Login
            // 
            this.AcceptButton = this.subBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(306, 183);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Login";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Please enter your credentials";
            this.Load += new System.EventHandler(this.Login_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loadingBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.LinkLabel changeDomain;
        private System.Windows.Forms.Label domainLabel;
        private System.Windows.Forms.MaskedTextBox pswTxt;
        private System.Windows.Forms.TextBox userTxt;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button subBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox serverTxt;
        private System.Windows.Forms.PictureBox loadingBox;
        private System.Windows.Forms.Button hiddenRes;
    }
}