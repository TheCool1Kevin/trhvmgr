﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr.Core
{
    /// <summary>
    /// This describes what a Main Window must have. This provides
    /// the basic framework for creation and tracking of custom DockContent windows.
    /// </summary>
    public class MainWindow : Form
    {
        #region Global Variables

        /// <summary>
        /// The main window MUST have an actions pane!
        /// </summary>
        public ActionsList ActionsListDockView
        {
            get
            {
                return GetDockPanels<ActionsList>()[0];
            }
        }

        /// <summary>
        /// I N S T A N C E :)
        /// </summary>
        public static MainWindow Instance { get; private set; }

        /// <summary>
        /// List of all dock panels
        /// </summary>
        internal Dictionary<Type, DockContent> DockContents;

        #endregion

        #region Constructor

        // These are all private and internal. These should not be modified.
        public DockPanel panel;
        private Dictionary<Type, DockState> DefaultDockContentStates;
        private Dictionary<Type, Action<DockContent>> DockAddedHandlers;
        private Dictionary<Type, Action> DockRemovedHandlers;
        private HashSet<Type> DockTypes;

        /// <summary>
        /// Constructor
        /// </summary>
        public MainWindow()
        {
            // Init variables
            Instance = this;
            DockContents = new Dictionary<Type, DockContent>();
            DockAddedHandlers = new Dictionary<Type, Action<DockContent>>();
            DockRemovedHandlers = new Dictionary<Type, Action>();
            DefaultDockContentStates = new Dictionary<Type, DockState>();
            DockTypes = new HashSet<Type>();

            // Other init actions
            AddDockType<ActionsList>(defaultDock: DockState.DockRight);
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Adds a dock type to the window.
        /// </summary>
        /// <param name="T">Typeof class of DockContent to add</param>
        /// <param name="eventAdded">Called when a new instance of the window is created.</param>
        /// <param name="eventRemoved">Called when an instance of the window is closed.</param>
        /// <param name="defaultDock">Default docking position.</param>
        public void AddDockType(
                Type T,
                Action<DockContent> eventAdded = null,
                Action eventRemoved = null,
                DockState defaultDock = DockState.Float
            )
        {
            if (DoesTypeExist(T)) return;
            DockTypes.Add(T);
            DefaultDockContentStates.Add(T, defaultDock);
            DockAddedHandlers.Add(T, eventAdded);
            DockRemovedHandlers.Add(T, eventRemoved);
        }

        /// <summary>
        /// Adds a dock type to the window.
        /// </summary>
        /// <typeparam name="T">Class of DockContent to add</typeparam>
        /// <param name="eventAdded">Called when a new instance of the window is created.</param>
        /// <param name="eventRemoved">Called when an instance of the window is closed.</param>
        /// <param name="defaultDock">Default docking position.</param>
        public void AddDockType<T>(
                Action<DockContent> eventAdded = null,
                Action eventRemoved = null,
                DockState defaultDock = DockState.Float
            ) where T : DockContent
        {
            if (DoesTypeExist(typeof(T))) return;
            DockTypes.Add(typeof(T));
            DefaultDockContentStates.Add(typeof(T), defaultDock);
            DockAddedHandlers.Add(typeof(T), eventAdded);
            DockRemovedHandlers.Add(typeof(T), eventRemoved);
        }

        /// <summary>
        /// Removes the dock type from the window.
        /// </summary>
        /// <typeparam name="T">Class of DockContent to remove.</typeparam>
        public void RemoveDockType<T>() where T : DockContent
        {
            if (!DoesTypeExist(typeof(T))) return;
            DockTypes.Remove(typeof(T));
            DefaultDockContentStates.Remove(typeof(T));
            DockAddedHandlers.Remove(typeof(T));
            DockRemovedHandlers.Remove(typeof(T));
        }

        /// <summary>
        /// Returns all dock panels.
        /// </summary>
        /// <typeparam name="T">The type of the panel.</typeparam>
        /// <returns></returns>
        public List<T> GetDockPanels<T>() where T : DockContent
        {
            List<T> res = new List<T>();
            foreach (var d in DockContents)
                if (typeof(T).IsAssignableFrom(d.Key) && d.Value != null)
                    res.Add(d.Value as T);
            return res;
        }

        /// <summary>
        /// Refreshes the action pane.
        /// </summary>
        /// <param name="d">The window that is active.</param>
        public void ReloadActionPane(IDockContent d)
        {
            if (!DockContents.ContainsKey(typeof(ActionsList))) return; // If window does not exist
            if (DockContents[typeof(ActionsList)] == null) return; // If window is not visible
            ((ActionsList) DockContents[typeof(ActionsList)]).LoadActions(d as ActionDock); // If the window has actions, load them
        }

        #endregion

        #region Internal Methods

        /// <summary>
        /// This adds a dockContent (window) to the dockPanel.
        /// </summary>
        /// <param name="dock">Should we assign a dock?</param>
        /// <typeparam name="T">The type of dock content we should add.</typeparam>
        /// <returns>The newly created instance.</returns>
        internal T AddWindow<T>(bool dock = true) where T : DockContent
        {
            Type TT = typeof(T);
            if (!DoesTypeExist(TT)) return default(T);
            if (GetDockPanels<T>().Count != 0) return default(T);
            T res = Activator.CreateInstance<T>();
            DockState s = default(DockState);
            DefaultDockContentStates.TryGetValue(TT, out s);
            if (s == default(DockState)) s = DockState.Float;
            if (dock) res.Show(panel, s);
            DockContents[TT] = res;
            Action<DockContent> p;
            DockAddedHandlers.TryGetValue(TT, out p);
            p?.Invoke((DockContent)Convert.ChangeType(res, typeof(DockContent)));
            return res;
        }

        /// <summary>
        /// This adds a dockContent (window) to the dockPanel.
        /// </summary>
        /// <param name="T">The type of dock content we should add.</param>
        /// <param name="dock">Should we assign a dock?</param>
        /// <returns>The newly created instance.</returns>
        internal DockContent AddWindow(Type T, bool dock = true)
        {
            if (!DoesTypeExist(T)) return null;
            if (!typeof(DockContent).IsAssignableFrom(T)) return null;
            DockContent d = null;
            DockContents.TryGetValue(T, out d);
            if (d != null) return null;
            DockContent res = (DockContent)Activator.CreateInstance(T);
            DockState s = default(DockState);
            DefaultDockContentStates.TryGetValue(T, out s);
            if (s == default(DockState)) s = DockState.Float;
            if (dock) res.Show(panel, s);
            DockContents[T] = res;
            Action<DockContent> p;
            DockAddedHandlers.TryGetValue(T, out p);
            p?.Invoke(res);
            return res;
        }

        /// <summary>
        /// Removes the dockcontent of type dockContent.
        /// </summary>
        /// <typeparam name="T">Type of window to remove.</typeparam>
        internal void RemoveWindow<T>()
        {
            if (!DoesTypeExist(typeof(T))) return;
            DockContents[typeof(T)] = null;
            DockRemovedHandlers[typeof(T)]?.Invoke();
        }

        /// <summary>
        /// Removes the dockcontent of type dockContent.
        /// </summary>
        /// <param name="dockContent">The typeof the class of the dockContent.</param>
        internal void RemoveWindow(IDockContent dockContent)
        {
            Type T = GetDockType(dockContent);
            if (T == null) return;
            DockContents[T] = null;
            DockRemovedHandlers[T]?.Invoke();
        }

        #endregion

        #region Private Methods

        private Type GetDockType(IDockContent dockContent)
        {
            foreach (var v in DockTypes)
                if (dockContent.GetType().IsAssignableFrom(v))
                    return v;
            return null;
        }

        private bool DoesTypeExist(Type T)
        {
            foreach (var v in DockTypes)
                if (T.IsAssignableFrom(v))
                    return true;
            return false;
        }

        #endregion
    }
}
