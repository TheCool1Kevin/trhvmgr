﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr.Core
{
    /// <summary>
    /// All windows who wish to contain a set of "actions" must
    /// inherit this class.
    /// </summary>
    public class ActionDock : DockContent
    {
        /// <summary>
        /// List of all actions.
        /// </summary>
        public List<ActionsListAction> ActionHandlers { get; set; }
        
        /// <summary>
        /// Different captions on the accordian header.
        /// </summary>
        public Dictionary<int, string> ActionCategories { get; set; }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public ActionDock() : this(null, null) { }

        /// <summary>
        /// Creates a new window that contains a set of valid actions.
        /// </summary>
        /// <param name="actions">List of valid actions.</param>
        /// <param name="categories">Categories each action will fall under.</param>
        public ActionDock(List<ActionsListAction> actions, Dictionary<int, string> categories) : base()
        {
            this.ActionHandlers = actions == null ? new List<ActionsListAction>() : actions;
            this.ActionCategories = categories == null ? new Dictionary<int, string>() : categories;
        }

        /// <summary>
        /// Forces the actions pane to reload the actions list for this window.
        /// </summary>
        public void MarkActionDirty()
        {
            // TODO: Make this a real mark dirty function. Right now, we're just reloading the actions pane.
            ((ActionsList)MainWindow.Instance.DockContents[typeof(ActionsList)]).ReloadActions(this);
        }
    }
}
