﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr
{
    public partial class OutputViewer : DockContent
    {
        private TextWriter _writer;

        public OutputViewer()
        {
            InitializeComponent();
        }

        private void OutputViewer_Load(object sender, EventArgs e)
        {
            _writer = new TextBoxStreamWriter(this.textBox1);
            Console.SetOut(_writer);
        }
    }

    public class TextBoxStreamWriter : TextWriter
    {
        TextBox _output = null;

        public TextBoxStreamWriter(TextBox output)
        {
            _output = output;
        }

        public override void Write(char value)
        {
            base.Write(value);
            _output.AppendText(value.ToString()); // When character data is written, append it to the text box.
        }

        public override Encoding Encoding
        {
            get { return Encoding.UTF8; }
        }
    }
}
