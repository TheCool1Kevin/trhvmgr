﻿using LiteDB;
using System;
using trhvmgr.Core.Database;

namespace trhvmgr.Server
{
    class Program
    {
        static bool running = false;
        static Server server;
        public static LiteDatabase db;
        public static object dbLock = new object();

        private static bool ClientConnected(string ip)
        {
            return true;
        }

        private static bool ClientDisconnected(string ip)
        {
            return true;
        }

        private static bool MessageReceived(string ip, byte[] data)
        {
            throw new NotImplementedException();
        }

        static void ParseCommand(string cmd)
        {
            switch (cmd.ToLowerInvariant())
            {
                case "quit":
                    running = false;
                    break;
                case "clients":
                    foreach (var v in server.GetClients())
                        Console.WriteLine("Client {0} from {1}", v.Key.ToString(), v.Value.Ip.ToString());
                    break;
                case "dblist":
                    foreach (string s in db.GetCollectionNames())
                        Console.WriteLine(s);
                    break;
                case "?":
                    break;
                default:
                    Console.WriteLine("Executing...");
                    try
                    {
                        foreach (var v in db.Engine.Run(cmd))
                            Console.WriteLine(v.ToString());
                    }
                    catch (LiteException ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                    break;
            }
        }

        static void Main(string[] args)
        {
            db = new LiteDatabase("ServerData.db");
            server = new Server("127.0.0.1", 3141);
            server.Start();
            Console.Title = "Server Console";
            running = true;
            while (running)
            {
                Console.Write("> ");
                string cmd = Console.ReadLine();
                ParseCommand(cmd);
            }
            server.Stop();
            db.Dispose();

            Console.WriteLine("Server closed. Press any key to exit...");
            Console.ReadKey();
        }
    }
}
