﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using trhvmgr.Core;

namespace trhvmgr.Server
{
    /// <summary>
    /// Client class processes the commands
    /// </summary>
    public class Client : IDisposable
    {
        TcpClient client;
        NetworkStream networkStream;
        SslStream ssl;
        BinaryReader br;
        BinaryWriter bw;
        ManualResetEvent tcpClientConnected;
        object bw_atomic = new object();

        private readonly Guid id;
        private bool isAuthenticated = false;

        public bool isDisposed { get; private set; }
        public bool isConnected { get; private set; }
        public IPEndPoint Ip { get; private set; }

        public Client(Guid id, ManualResetEvent e)
        {
            isDisposed = false;
            tcpClientConnected = e;
            this.id = id;
            this.isAuthenticated = false;
        }

        public void DoAcceptTcpClientCallback(IAsyncResult ar)
        {
            TcpListener listener = (TcpListener)ar.AsyncState;
            client = listener.EndAcceptTcpClient(ar);
            Ip = (IPEndPoint)client.Client.RemoteEndPoint;
            Debug.WriteLine("Client {0} has connected from {1}.", id.ToString(), Ip.Address.ToString());
            tcpClientConnected.Set();
            networkStream = client.GetStream();
            ssl = new SslStream(networkStream, false);
            X509Certificate2 cert = new X509Certificate2("server.pfx", "serverpasswordnoonecaresabout");

            try
            {
                ssl.AuthenticateAsServer(cert, false, SslProtocols.Tls, true);
            }
            catch (IOException ex)
            {
                // Some type of problem initiating the SSL connection
                Debug.WriteLine(ex.Message);
                switch (ex.Message)
                {
                    case "Authentication failed because the remote party has closed the transport stream.":
                    case "Unable to read data from the transport connection: An existing connection was forcibly closed by the remote host.":
                        Debug.WriteLine("*** StartTls IOException " + id.ToString() + " closed the connection.");
                        break;
                    case "The handshake failed due to an unexpected packet format.":
                        Debug.WriteLine("*** StartTls IOException " + id.ToString() + " disconnected, invalid handshake.");
                        break;
                    default:
                        Debug.WriteLine("*** StartTls IOException from " + id.ToString() + Environment.NewLine + ex.ToString());
                        break;
                }

                Dispose();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine("*** StartTls Exception from " + id.ToString() + Environment.NewLine + ex.ToString());
                Dispose();
            }

            //DisplaySecurityLevel(ssl);
            //DisplaySecurityServices(ssl);
            //DisplayCertificateInformation(ssl);
            //DisplayStreamProperties(ssl);
            //ssl.ReadTimeout = 5000;
            ssl.WriteTimeout = 5000;

            isConnected = true;

            br = new BinaryReader(ssl, Encoding.UTF8);
            bw = new BinaryWriter(ssl, Encoding.UTF8);
            bw.Write((byte)PacketTypes.MESSAGE);
            bw.Write("Server says hello. Please register yourself.");
            while (!isAuthenticated && !isDisposed) doAuthenticate();
            while (isConnected && isAuthenticated && !isDisposed)
            {
                string col, jsondoc, bsondoc;
                switch ((PacketTypes)SafeReadByte())
                {
                    case PacketTypes.INSERT:
                        {
                            col = SafeReadString();
                            jsondoc = SafeReadString();
                            if (col == null || jsondoc == null) return;
                            lock (Program.dbLock)
                            {
                                try
                                {
                                    Program.db.GetCollection(col).EnsureIndex("Self", true);
                                    Program.db.GetCollection(col).Insert(JsonSerializer.Deserialize(jsondoc).AsDocument);
                                }
                                catch (LiteException) { }
                            }
                        }
                        break;
                    case PacketTypes.FIND:
                        {
                            col = SafeReadString();
                            bsondoc = SafeReadString();
                            if (col == null || bsondoc == null) return;
                            List<BsonValue> l = new List<BsonValue>();
                            try
                            {
                                BsonExpression ex = new BsonExpression(bsondoc);
                                foreach (var f in Program.db.GetCollection(col).FindAll())
                                    l.AddRange(ex.Execute(f, false));
                            }
                            catch (LiteException) { }
                            lock (bw_atomic)
                            {
                                bw.Write((byte)PacketTypes.RESPONSE);
                                bw.Write(l.Count);
                                foreach (var s in l) bw.Write(s.ToString());
                            }
                        }
                        break;
                    case PacketTypes.EXECUTE:
                        {
                            col = SafeReadString();
                            if (col == null) return;
                            try
                            {
                                var l = Program.db.Engine.Run(col);
                                lock (bw_atomic)
                                {
                                    bw.Write((byte)PacketTypes.RESPONSE);
                                    bw.Write(l.Count);
                                    foreach (var s in l) bw.Write(s.ToString());
                                }
                            }
                            catch (LiteException) { }
                            break;
                        }
                    default:
                        break;
                }
            }
        }

        public bool SendPing()
        {
            try
            {
                lock (bw_atomic)
                {
                    bw.Flush();
                    bw.Write((byte)PacketTypes.PING);
                }
                return client.Connected;
            }
            catch (IOException)
            {
                return false;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }

        public void Dispose()
        {
            isDisposed = true;
            br.Dispose();
            bw.Dispose();
            ssl.Dispose();
            networkStream.Dispose();
            client.Close();
        }

        private void doAuthenticate()
        {
            try
            {
                string[] cred = br.ReadString().Split(';');
                if (cred.Length != 2) throw new InvalidCredentialException(); // Someone tryna sabotage us
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                if (!ctx.ValidateCredentials(cred[0], cred[1], ContextOptions.Negotiate))
                    throw new InvalidCredentialException();
                isAuthenticated = true;
                Debug.WriteLine("Client " + this.id.ToString() + " auth success.");
                bw.Write((byte)PacketTypes.AUTHOK);
            }
            catch (InvalidCredentialException)
            {
                Debug.WriteLine("Client " + this.id.ToString() + " auth failed.");
                bw.Write((byte)PacketTypes.AUTHNO);
            }
            catch (Exception)
            {
                Debug.WriteLine("Client " + this.id.ToString() + " auth errored, going to disconnect.");
                this.Dispose();
            }
        }

        private byte SafeReadByte()
        {
            try
            {
                return br.ReadByte();
            }
            catch (Exception e)
            {
                this.Dispose();
            }
            return 0;
        }

        private string SafeReadString()
        {
            try
            {
                return br.ReadString();
            }
            catch (Exception e)
            {
                this.Dispose();
            }
            return null;
        }
    }
}
