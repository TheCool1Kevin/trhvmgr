﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace trhvmgr.Server
{
    // Server-side management (i.e., managing and creating connections)
    public class Server
    {
        bool running = false;
        ManualResetEvent tcpClientConnected = new ManualResetEvent(false);
        ConcurrentDictionary<Guid, Client> clients;
        object clientsLock = new object();
        readonly string ip;
        readonly int port;

        public Server(string ip, int port)
        {
            this.ip = ip;
            this.port = port;
            clients = new ConcurrentDictionary<Guid, Client>();
        }

        public void Start()
        {
            running = true;
            new Thread(StartServerThread).Start();
            new Thread(StartServerPingThread).Start();
        }

        public void Stop()
        {
            running = false;
        }

        public void StartServerThread()
        {
            TcpListener server = new TcpListener(IPAddress.Parse(ip), port);
            server.Start();
            Debug.WriteLine("Server started. Waiting for client connections...");
            while (running)
            {
                tcpClientConnected.Reset();
                Guid id = Guid.NewGuid();
                Client c = new Client(id, tcpClientConnected);
                server.BeginAcceptSocket(new AsyncCallback(c.DoAcceptTcpClientCallback), server);
                tcpClientConnected.WaitOne();
                while (!clients.TryAdd(id, c)) ;
            }
            foreach (var c in clients)
                c.Value.Dispose();
            server.Stop();
        }

        public void StartServerPingThread()
        {
            while (running)
            {
                List<Guid> remove = new List<Guid>();
                Dictionary<Guid, Client> cc = clients.ToDictionary(v => v.Key, v => v.Value);
                foreach (var c in cc)
                {
                    if(c.Value.isDisposed || !c.Value.isConnected || !c.Value.SendPing())
                        remove.Add(c.Key);
                }
                foreach (var r in remove)
                {
                    Client c;
                    Debug.WriteLine("Client " + r.ToString() + " has disconnected.");
                    clients.TryRemove(r, out c);
                    c?.Dispose();
                }

                Thread.Sleep(1500); // 1.5 Seconds
            }
        }

        public Dictionary<Guid, Client> GetClients()
        {
            return clients.ToDictionary(v => v.Key, v => v.Value);
        }
    }
}
