﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core.Types
{
    /// <summary>
    /// Class to describe a server
    /// </summary>
    
    public class Server
    {
        public int Id { get; private set; }
        public PhysicalAddress MacAddress { get; private set; }
        public IPAddress IpAddress { get; private set; }
        public string HostName { get; private set; }
        public List<VirtualMachine> VirtualMachines { get; private set; }
        public long MacBegin { get; private set; }
        public long MacEnd { get; private set; }

        /// <summary>
        /// Populate the server object with extracted parameters
        /// </summary>
        /// <param name="hostName">Hostname of the server</param>
        public Server(string hostName)
        {
            // TODO: Exception Catching
            IpAddress = Dns.GetHostEntry(hostName).AddressList[0];
            MacAddress = ArpRequest.Send(IpAddress).Address;
            PlugInterface.BringOnline(hostName);
            this.HostName = hostName;
            this.VirtualMachines = new List<VirtualMachine>();
            this.UpdateVmList();
        }

        public void UpdateVmList()
        {
            VirtualMachines.Clear();
            VirtualMachines.AddRange(PlugInterface.GetVms(this.HostName));
        } // End UpdateVmList
    }
}
