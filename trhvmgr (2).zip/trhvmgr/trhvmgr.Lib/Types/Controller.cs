﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core.Types
{
    /// <summary>
    /// Class to describe a controller server
    /// </summary>
    public class Controller : Server
    {
        public List<Server> Servers { get; private set; }
        public List<VirtualMachine> TemplateVMs { get; private set; }
        public List<VirtualMachine> BaseVMs { get; private set; }

        private Dictionary<string, Server> dict;

        public Controller(string hostName) : base(hostName)
        {
            Servers = new List<Server>();
            TemplateVMs = new List<VirtualMachine>();
            BaseVMs = new List<VirtualMachine>();
            dict = new Dictionary<string, Server>();
            dict.Add(hostName, this);
        }

        public Server GetServer(string hostName)
        {
            return dict[hostName];
        }
    }
}
