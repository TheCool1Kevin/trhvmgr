﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core.Database
{
    public class ServerObject
    {
        [LiteDB.BsonId]
        public Guid Id { get; set; }
        public string HostName { get; set; }
        public string IpAddress { get; set; }
        public string MacAddress { get; set; }
        public bool IsController { get; set; }
    }

    public class VirtualMachineObject
    {
        [LiteDB.BsonId]
        public Guid Self { get; set; } // Self
        public Guid Parent { get; set; }
        public int Type { get; set; } // Needed?
    }
}
