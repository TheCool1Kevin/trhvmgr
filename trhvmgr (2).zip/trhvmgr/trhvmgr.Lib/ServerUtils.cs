﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core
{
    public enum PacketTypes
    {
        PING = 0x2A, //42: The answer to life, the universe and everything
        MESSAGE = 0x1,
        AUTHOK, AUTHNO,
        INSERT, EXECUTE, FIND, RESPONSE,
        FORCE_UPDATE, // Force clients to update state
        // TODO: Prevent DDoS attacks
        NOTIFY_UPDATE // Client notifies server of updated state
    }

    // Database Operations
    public static class ServerUtils
    {
        public static byte GetNextRealPacketByte(BinaryReader br)
        {
            while (true)
            {
                byte b = br.ReadByte();
                if (b != (byte)PacketTypes.PING) return b;
            }
        }
    }

    public class ServerClient
    {
        TcpClient client;
        NetworkStream networkStream;
        SslStream ssl;
        public BinaryReader br { get; private set; }
        public BinaryWriter bw { get; private set; }
        // Mappuu
        BsonMapper mapper = BsonMapper.Global;

        private bool ValidateCert(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors == SslPolicyErrors.None)
                return true;
            Console.WriteLine("Certificate error: {0}", sslPolicyErrors);
            foreach (var ch in chain.ChainStatus)
                Console.WriteLine("Status: {0} {1}", ch.Status, ch.StatusInformation);
            return true; // Allow untrusted certificates anyways.
        }

        public ServerClient()
        {
            client = new TcpClient("localhost", 3141);
            networkStream = client.GetStream();
            ssl = new SslStream(networkStream, false, new RemoteCertificateValidationCallback(ValidateCert));
            ssl.AuthenticateAsClient("localhost");
            br = new BinaryReader(ssl, Encoding.UTF8);
            bw = new BinaryWriter(ssl, Encoding.UTF8);
            // Read welcome message & authenticate
            if (br.ReadByte() == (byte)PacketTypes.MESSAGE) br.ReadString();
            do
            {
                var cred = new NetworkCredential(SessionState.Instance.PSCredential.UserName, SessionState.Instance.PSCredential.Password);
                bw.Write(cred.UserName + ";" + cred.Password);
            } while (ServerUtils.GetNextRealPacketByte(br) == (byte)PacketTypes.AUTHNO);

            mapper.Entity<Database.VirtualMachineObject>()
                    .Field(x => x.Self, "_id")
                    .Field(x => x.Parent, "Parent")
                    .Field(x => x.Type, "Type");
        }

        public int GetVmIndex(string guid)
        {
            //bw.Write((byte)PacketTypes.FIND);
            //bw.Write("VirtualMachines");
            //bw.Write("{_id:$.Self,Type:$.Type}");
            bw.Write((byte)PacketTypes.EXECUTE);
            bw.Write("db.VirtualMachines.find _id = {\"$guid\":\"" + guid + "\"}");
            ServerUtils.GetNextRealPacketByte(br);
            int lim = br.ReadInt32();
            for(int i = 0; i < lim; i++)
            {
                var doc = JsonSerializer.Deserialize(br.ReadString()).AsDocument;
                return doc["Type"].AsInt32;
            }
            return 0;
        }

        public void AddVm(Database.VirtualMachineObject vm)
        {
            bw.Write((byte)PacketTypes.INSERT);
            bw.Write("VirtualMachines");
            BsonDocument doc = mapper.ToDocument(vm);
            string s = JsonSerializer.Serialize(doc, true);
            bw.Write(s);
        }
    }
}
