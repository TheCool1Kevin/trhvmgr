﻿using System;
using System.Windows.Forms;

namespace trhvmgr.Dialogs
{
    public partial class UserInputDialog : Form
    {
        public UserInputDialog(string title) : this(title, "") { }

        public UserInputDialog(string title, string defaultText)
        {
            InitializeComponent();
            this.Text = title;
            textBox1.Text = defaultText;
        }

        public string GetUserInput()
        {
            return textBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
    }
}
