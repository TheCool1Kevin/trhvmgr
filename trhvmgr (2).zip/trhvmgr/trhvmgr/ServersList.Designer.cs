﻿namespace trhvmgr
{
    partial class ServersList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServersList));
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.serverView = new trhvmgr.UI.NativeTreeView();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "organization.png");
            this.imageList.Images.SetKeyName(1, "dist-color.png");
            this.imageList.Images.SetKeyName(2, "icons8-server-25.png");
            this.imageList.Images.SetKeyName(3, "server-error.png");
            this.imageList.Images.SetKeyName(4, "server-denied.png");
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.serverView);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(392, 522);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(392, 547);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // serverView
            // 
            this.serverView.CheckBoxes = true;
            this.serverView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.serverView.FullRowSelect = true;
            this.serverView.ImageIndex = 0;
            this.serverView.ImageList = this.imageList;
            this.serverView.Indent = 25;
            this.serverView.ItemHeight = 40;
            this.serverView.Location = new System.Drawing.Point(0, 0);
            this.serverView.Name = "serverView";
            this.serverView.PathSeparator = "/";
            this.serverView.SelectedImageIndex = 0;
            this.serverView.ShowLines = false;
            this.serverView.ShowNodeToolTips = true;
            this.serverView.Size = new System.Drawing.Size(392, 522);
            this.serverView.TabIndex = 0;
            this.serverView.AutoCheck += new trhvmgr.UI.NativeTreeView.AutoCheckEventHandler(this.serverView_AutoCheck);
            this.serverView.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.serverView_AfterCheck);
            // 
            // ServersList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 547);
            this.Controls.Add(this.toolStripContainer1);
            this.Name = "ServersList";
            this.Text = "Servers";
            this.Load += new System.EventHandler(this.ServersList_Load);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private trhvmgr.UI.NativeTreeView serverView;
    }
}