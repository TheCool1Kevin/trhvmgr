﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using trhvmgr.Core;
using WeifenLuo.WinFormsUI.Docking;
using static trhvmgr.UI.Accordion;

namespace trhvmgr.Core
{
    /// <summary>
    /// This is the only special DockContent Class. This window
    /// is the actual actions window the user will see.
    /// </summary>
    public partial class ActionsList : DockContent
    {
        private UI.Accordion accordion;
        private ActionDock current;

        public ActionsList()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Populates the window with the correct actions
        /// </summary>
        /// <param name="ad">The window to load actions from.</param>
        public void LoadActions(ActionDock ad)
        {
            // State control
            if (ad == null) return;
            current = ad;
            List<ActionsListAction> actions = ad.ActionHandlers;
            Dictionary<int, string> categories = ad.ActionCategories;

            // Reset accordion
            this.Controls.Remove(accordion);
            accordion = new UI.Accordion();
            //accordion.BackColor = Color.White;
            Reinitaccordion();

            // Add all panels
            Dictionary<int, TableLayoutPanel> panels = new Dictionary<int, TableLayoutPanel>();
            foreach(var c in categories)
                panels.Add(c.Key, new TableLayoutPanel { Dock = DockStyle.Fill });
            
            // Add all buttons
            foreach(var a in actions)
            {
                if (!a.IsVisible()) continue;
                TableLayoutPanel p = null;
                panels.TryGetValue(a.Category, out p);
                if (p == null) continue;
                Button b = new Button
                {
                    Text = a.Caption,
                    Dock = DockStyle.Fill,
                    Height = 30,
                    Margin = new Padding(0),
                    TextImageRelation = TextImageRelation.ImageBeforeText,
                    TextAlign = ContentAlignment.MiddleLeft,
                    FlatStyle = FlatStyle.Flat,
                    Cursor = Cursors.Hand
                };
                b.FlatAppearance.BorderSize = 0;
                b.FlatAppearance.MouseDownBackColor = Color.DarkGray;
                b.FlatAppearance.MouseOverBackColor = Color.Silver;
                b.FlatAppearance.CheckedBackColor = Color.White;

                b.Click += (s, e) => { a.Action?.Invoke(); }; // TODO: Add more somehow
                p.RowCount++;
                p.Controls.Add(b, 0, p.RowCount - 1); // 0 indexed
            }
            
            // Configure and add each panel
            foreach(var p in panels)
            {
                // Each panel has fixed height
                foreach(RowStyle r in p.Value.RowStyles)
                {
                    r.SizeType = SizeType.Absolute;
                    r.Height = 30;
                }

                // Then add it to the accorian
                accordion.Add(p.Value, categories[p.Key], "", 0, true);
            }

            this.Controls.Add(accordion);
        }

        /// <summary>
        /// Reloads the actions of a window if it is active.
        /// </summary>
        /// <param name="ad">The window to reload.</param>
        public void ReloadActions(ActionDock ad)
        {
            if (current != ad) return;
            LoadActions(ad);
        }

        /// <summary>
        /// Copied from ActionsList.Desiger.cs
        /// </summary>
        private void Reinitaccordion()
        {
            this.accordion.AddResizeBars = true;
            this.accordion.AllowMouseResize = true;
            this.accordion.AnimateCloseEffect = ((trhvmgr.UI.AnimateWindowFlags)(((trhvmgr.UI.AnimateWindowFlags.VerticalNegative | trhvmgr.UI.AnimateWindowFlags.Hide)
            | trhvmgr.UI.AnimateWindowFlags.Slide)));
            this.accordion.AnimateCloseMillis = 300;
            this.accordion.AnimateOpenEffect = ((trhvmgr.UI.AnimateWindowFlags)(((trhvmgr.UI.AnimateWindowFlags.VerticalPositive | trhvmgr.UI.AnimateWindowFlags.Show)
            | trhvmgr.UI.AnimateWindowFlags.Slide)));
            this.accordion.AnimateOpenMillis = 300;
            this.accordion.AutoFixDockStyle = true;
            this.accordion.AutoScroll = true;
            this.accordion.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.accordion.CheckBoxFactory = new MyCbFctry();
            this.accordion.CheckBoxMargin = new System.Windows.Forms.Padding(0);
            this.accordion.ContentBackColor = null;
            this.accordion.ContentMargin = null;
            this.accordion.ContentPadding = new System.Windows.Forms.Padding(5);
            this.accordion.ControlBackColor = null;
            this.accordion.ControlMinimumHeightIsItsPreferredHeight = true;
            this.accordion.ControlMinimumWidthIsItsPreferredWidth = true;
            this.accordion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.accordion.DownArrow = null;
            this.accordion.FillHeight = true;
            this.accordion.FillLastOpened = false;
            this.accordion.FillModeGrowOnly = false;
            this.accordion.FillResetOnCollapse = false;
            this.accordion.FillWidth = true;
            this.accordion.GrabCursor = System.Windows.Forms.Cursors.SizeNS;
            this.accordion.GrabRequiresPositiveFillWeight = true;
            this.accordion.GrabWidth = 6;
            this.accordion.GrowAndShrink = true;
            this.accordion.Insets = new System.Windows.Forms.Padding(0);
            this.accordion.Location = new System.Drawing.Point(0, 0);
            this.accordion.Name = "accordion";
            this.accordion.OpenOnAdd = false;
            this.accordion.OpenOneOnly = false;
            this.accordion.ResizeBarFactory = null;
            this.accordion.ResizeBarsAlign = 0.5D;
            this.accordion.ResizeBarsArrowKeyDelta = 10;
            this.accordion.ResizeBarsFadeInMillis = 800;
            this.accordion.ResizeBarsFadeOutMillis = 800;
            this.accordion.ResizeBarsFadeProximity = 24;
            this.accordion.ResizeBarsFill = 1D;
            this.accordion.ResizeBarsKeepFocusAfterMouseDrag = false;
            this.accordion.ResizeBarsKeepFocusIfControlOutOfView = true;
            this.accordion.ResizeBarsKeepFocusOnClick = true;
            this.accordion.ResizeBarsMargin = null;
            this.accordion.ResizeBarsMinimumLength = 50;
            this.accordion.ResizeBarsStayInViewOnArrowKey = true;
            this.accordion.ResizeBarsStayInViewOnMouseDrag = true;
            this.accordion.ResizeBarsStayVisibleIfFocused = true;
            this.accordion.ResizeBarsTabStop = true;
            this.accordion.ShowPartiallyVisibleResizeBars = false;
            this.accordion.ShowToolMenu = true;
            this.accordion.ShowToolMenuOnHoverWhenClosed = false;
            this.accordion.ShowToolMenuOnRightClick = true;
            this.accordion.ShowToolMenuRequiresPositiveFillWeight = false;
            this.accordion.Size = new System.Drawing.Size(348, 476);
            this.accordion.TabIndex = 0;
            this.accordion.UpArrow = null;
        }
    }

    public class MyCbFctry : ICheckBoxFactory
    {
        public virtual CheckBox CreateCheckBox(String text, bool check, Padding margin)
        {
            CheckBox cb = new CheckBox();
            cb.Appearance = Appearance.Button;
            cb.AutoSize = false; // AutoSize must be true or the text will wrap under and be hidden
            cb.Height = 40;
            cb.Checked = check;
            cb.Text = text;
            cb.Anchor = AnchorStyles.Left | AnchorStyles.Right; // cb.Dock = DockStyle.Fill also works.
            cb.Margin = margin; // typically 0 so that no are gaps between the buttons
            cb.AutoEllipsis = true;
            cb.Cursor = Cursors.Hand;
            return cb;
        }
    }

}
