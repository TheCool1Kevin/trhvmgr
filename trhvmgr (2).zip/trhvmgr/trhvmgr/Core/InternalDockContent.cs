﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr.Core
{
    /// <summary>
    /// I don't really know if this is necessary...
    /// </summary>
    public class InternalDockContent : DockContent
    {
        protected readonly string GUID;

        public InternalDockContent()
        {
            GUID = Guid.NewGuid().ToString();
        }

        public override bool Equals(object obj)
        {
            var content = obj as InternalDockContent;
            return content != null && GUID == content.GUID;
        }

        public override int GetHashCode()
        {
            return -762187988 + EqualityComparer<string>.Default.GetHashCode(GUID);
        }
    }
}
