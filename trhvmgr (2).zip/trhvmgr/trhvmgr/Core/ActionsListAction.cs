﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Core
{
    /// <summary>
    /// An action.
    /// </summary>
    public class ActionsListAction
    {
        public int ImageIndex { get; set; }
        public int Category { get; set; }
        public string Caption { get; set; }
        public Action Action { get; set; }
        public Func<bool> IsVisible { get; set; } = () => { return true; };
    }
}
