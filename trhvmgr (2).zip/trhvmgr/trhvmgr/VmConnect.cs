﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using trhvmgr.Core;
using trhvmgr.Core.Types;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr
{
    public partial class VmConnect : DockContent
    {
        private string host, vmid, tt;
        bool newWindow = false;
        private Process p;
        public VmConnect(string hn, string vm, string title, bool newWindow = false)
        {
            host = hn; vmid = vm; this.Text = title; this.newWindow = newWindow;
            InitializeComponent();
        }

        [DllImport("user32.dll")]
        static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

        [DllImport("user32.dll")]
        static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll")]
        static extern bool MoveWindow(IntPtr Handle, int x, int y, int w, int h, bool repaint);

        static readonly int GWL_STYLE = -16;
        static readonly int WS_VISIBLE = 0x10000000;

        private void panel1_SizeChanged(object sender, EventArgs e)
        {
            if (p != null && !newWindow && !p.HasExited)
                MoveWindow(p.MainWindowHandle, 0, 0, panel1.Width, panel1.Height, true);
        }

        private void VmConnect_Load(object sender, EventArgs e)
        {
            string user = "richmondhill" + "\\" + SessionState.Instance.PSCredential.GetNetworkCredential().UserName;
            p = Process.Start("wfreerdp.exe", "/u:" + user +
                " /p:" + SessionState.Instance.PSCredential.GetNetworkCredential().Password +
                " /v:" + host +
                " /vmconnect:" + vmid.ToUpperInvariant());
            if (newWindow) return;
            p.WaitForInputIdle();
            Thread.Sleep(500);
            if (p.HasExited) return;
            SetParent(p.MainWindowHandle, panel1.Handle);
            SetWindowLong(p.MainWindowHandle, GWL_STYLE, WS_VISIBLE);
            MoveWindow(p.MainWindowHandle, 0, 0, panel1.Width, panel1.Height, true);
        }
    }
}
