﻿#define DoLogin

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using trhvmgr.Core;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr
{
    public partial class MainFrm : MainWindow
    {
        #region Global Variables

        // This is where the main form's layout is saved to
        private static readonly string xmlFile = "MainState.xml";
        // Have we logged in an validated?
        private bool isValidSession = false;

        public string StatusText
        {
            get { return ""; }
            set
            {
                statusLabel.Text = value;
                statusLabel.Invalidate();
            }
        }

        #endregion

        #region Constructors

        public MainFrm() : base()
        {
            InitializeComponent();
            dockPanel.Theme = new VS2015BlueTheme();
            base.panel = dockPanel;
            // Register all window types
            AddDockType<ServersList>(defaultDock: DockState.DockLeft);
            AddDockType<VmsList>(defaultDock: DockState.Document);
            AddDockType<Performance>(defaultDock: DockState.DockBottomAutoHide);
            AddDockType<OutputViewer>(defaultDock: DockState.DockBottomAutoHide);
            AddDockType<ActionsList>(defaultDock: DockState.DockRight);
        }

        #endregion

        #region Events

        private void MainFrm_Load(object sender, EventArgs e)
        {
            if(!File.Exists("trhvmgr.Plugs.dll"))
            {
                MessageBox.Show("Error", "Plugin dll not found!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            PlugInterface.Init(Path.GetFullPath("trhvmgr.Plugs.dll"),
                s => MessageBox.Show("Error", s, MessageBoxButtons.OK, MessageBoxIcon.Error),
                s => WriteStatus(s));

#if DoLogin
            if (new Login().ShowDialog() != DialogResult.OK)
            {
                this.Close();
                return;
            }
#endif

            isValidSession = true;
            if (File.Exists(xmlFile))
                dockPanel.LoadFromXml(xmlFile, (str) => AddWindow(Type.GetType(str), false));
            else
            {
                AddWindow(typeof(ActionsList));
                AddWindow(typeof(ServersList));
                AddWindow(typeof(VmsList));
                AddWindow(typeof(OutputViewer));
            }

            WindowState = Properties.Settings.Default.F1State;
            Size = Properties.Settings.Default.F1Size.IsEmpty ? this.Size : Properties.Settings.Default.F1Size;

            RefreshAll();
        }

        private void MainFrm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isValidSession)
            {
                dockPanel.SaveAsXml(xmlFile);
                Properties.Settings.Default.F1State = WindowState;
                if (WindowState == FormWindowState.Normal)
                    Properties.Settings.Default.F1Size = Size;
                else
                    Properties.Settings.Default.F1Size = RestoreBounds.Size;
                // Don't forget to save the settings
                Properties.Settings.Default.Save();
            }
        }

        private void dockPanel_ContentRemoved(object sender, DockContentEventArgs e)
        {
            RemoveWindow(e.Content);
        }

        private void actionsListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddWindow(typeof(ActionsList))?.Select();
        }

        private void serversListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddWindow(typeof(ServersList))?.Select();
        }

        private void virtualMachinesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddWindow(typeof(VmsList))?.Select();
        }

        private void outputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddWindow(typeof(OutputViewer))?.Select();
        }

        private void dockPanel_ActivePaneChanged(object sender, EventArgs e)
        {
            ReloadActionPane(dockPanel.ActiveContent);
        }

        #endregion

        #region Private Methods

        private void WriteStatus(string s)
        {
            if (InvokeRequired)
                Invoke((MethodInvoker)delegate { WriteStatus(s); });
            else
                StatusText = s;
        }

        #endregion

        #region Public Methods

        public void RefreshAll()
        {
            GetDockPanels<VmsList>()[0].RefreshListAsync();
            GetDockPanels<ServersList>()[0].RefreshList();
        }

        #endregion

        private void addVMToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
