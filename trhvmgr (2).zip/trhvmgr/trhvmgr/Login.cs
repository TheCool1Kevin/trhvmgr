﻿// Commment these out to disable (for debugging only)
#define Authenticate
#define DoADChecks

using System;
using System.Windows.Forms;
using System.DirectoryServices.AccountManagement;
using System.Management.Automation;

using trhvmgr.Properties;
using trhvmgr.Dialogs;
using CPI.DirectoryServices;
using System.Net.NetworkInformation;
using System.Net;
using System.Threading.Tasks;
using System.Security;

namespace trhvmgr
{
    /// <summary>
    /// This is the login form that will handle the credentials.
    /// </summary>
    public partial class Login : Form
    {
        #region Global Variables

        private string domain;
        private Ping pingSender;
        private object locked = new object();

        public PSCredential Credentials { get; private set; }

        #endregion

        #region Constructor

        public Login()
        {
            InitializeComponent();
            //domain = Environment.UserDomainName;
            domain = IPGlobalProperties.GetIPGlobalProperties().DomainName;
            pingSender = new Ping();
        }

        #endregion

        #region Form Events

        private void Login_Load(object sender, EventArgs e)
        {
            domainLabel.Text = "Domain: " + domain;
            // Load user settings
            userTxt.Text = Settings.Default.Username;
            serverTxt.Text = Settings.Default.ControllerName;
        }

        private void changeDomain_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            UserInputDialog dialog = new UserInputDialog("Change Domain", domain);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string res = dialog.GetUserInput().Replace('\\', ' ');
                res.Replace('/', ' ');
                res = res.Trim();
                res = res.ToUpperInvariant();
                if (!string.IsNullOrEmpty(res) && res != ".")
                    domainLabel.Text = "Domain: " + res;
                else
                    MessageBox.Show("Domain name invalid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void subBtn_Click(object sender, EventArgs e)
        {
#if DoADChecks
            // Do checks to ensure the domain is valid
            PrincipalContext ctx = null;
            UserPrincipal usr = null;
            try {
                ctx = new PrincipalContext(ContextType.Domain);
            } catch (Exception) { }

            if(ctx == null || ctx.ConnectedServer == null)
            {
                MessageBox.Show("Invalid domain.", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.None;
                return;
            }

            try {
                usr = UserPrincipal.FindByIdentity(ctx, IdentityType.SamAccountName, userTxt.Text);
            } catch(Exception) { }

            if (usr == null)
            {
                MessageBox.Show("Username or password is invalid.", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.None;
                return;
            }

            // Check if account is MCA, if not, still allow the user to continue, but warn them
            bool isMca = false;
            foreach (var g in usr.GetGroups())
            {
                DN dname = new DN(g.DistinguishedName);
                DN mca = new DN("CN=MCA Administrators,OU=Security Groups,OU=TRH,DC=richmondhill,DC=local");
                if (dname.Equals(mca))
                {
                    isMca = true;
                    break;
                }
            }

            if (!isMca && MessageBox.Show("This is not an MCA account. Do you want to continue?", "Incorrect Privilege",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
            {
                DialogResult = DialogResult.None;
                return;
            }

    #if Authenticate
            try
            {
                // Check if credentials are valid. ContextOptions.Negotiate is needed to force
                // Kerberos instead of CredSSP (for use, CredSSP is disabled/used very little)
                if (!ctx.ValidateCredentials(userTxt.Text, pswTxt.Text, ContextOptions.Negotiate))
                {
                    MessageBox.Show("Username or password is invalid.", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DialogResult = DialogResult.None;
                    return;
                }
            } catch(Exception)
            {
                MessageBox.Show("Username or password is invalid.", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.None;
                return;
            }
    #endif
#endif
            if(string.IsNullOrEmpty(serverTxt.Text))
            {
                MessageBox.Show("Server name cannot be empty!");
                DialogResult = DialogResult.None;
                return;
            }

            Hide();
            PSCredential cred = new PSCredential(userTxt.Text, new NetworkCredential("", pswTxt.Text).SecurePassword);
            LoadingDialog ld = new LoadingDialog(serverTxt.Text, cred);
            if (ld.ShowDialog() == DialogResult.OK)
            {
                
            }

            else return;

            Settings.Default.ControllerName = serverTxt.Text;
            Settings.Default.Username = userTxt.Text;
            Settings.Default.Save();
            DialogResult = DialogResult.OK;
            hiddenRes.PerformClick();
        }

        private void serverName_TextChanged(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                // Only allow one instance to run at a time.
                lock (locked)
                {
                    try
                    {
                        GetStatus();
                    }
                    catch (Exception) { }

                }
            });
        }

        #endregion

        #region Private Methods

        private void GetStatus()
        {
            // Get IP
            // Change the image if it hasn't been changed already
            Invoke((MethodInvoker)delegate
            {
                if (loadingBox.Image != Resources.loading)
                {
                    loadingBox.Image = Resources.loading;
                    loadingBox.SizeMode = PictureBoxSizeMode.CenterImage;
                }
            });
            var hostEntry = Dns.GetHostAddresses(serverTxt.Text);
            try
            {
                // Ping server status
                var a = pingSender.Send(hostEntry[0], 1000);
                try
                {
                    if (a.Status == IPStatus.Success) Invoke((MethodInvoker)delegate
                    {
                        loadingBox.Image = Resources.ok;
                        loadingBox.SizeMode = PictureBoxSizeMode.StretchImage;
                    });

                    else throw new Exception();
                }
                catch (Exception)
                {
                    // Stuping f*cking invoke is needed because tasks
                    // cannot access the main GUI thread.
                    Invoke((MethodInvoker)delegate
                    {
                        loadingBox.Image = Resources.error;
                        loadingBox.SizeMode = PictureBoxSizeMode.StretchImage;
                    });
                }
            }
            catch (Exception)
            {
                Invoke((MethodInvoker)delegate
                {
                    loadingBox.Image = Resources.error;
                    loadingBox.SizeMode = PictureBoxSizeMode.StretchImage;
                });
            }
        }

        #endregion
    }
}
