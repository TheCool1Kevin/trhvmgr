﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using trhvmgr.Core;
using trhvmgr.Core.Types;
using WeifenLuo.WinFormsUI.Docking;

namespace trhvmgr
{
    public partial class ServersList : ActionDock
    {
        private TreeNode rootNode;
        private TreeNode distNode;

        #region Constructor

        public ServersList() : base()
        {
            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Power On",
                Action = () => { PlugInterface.StartServer(GetSelectedServers()); },
                Category = 0
            });

            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Shutdown",
                Action = () => { PlugInterface.StopServer(GetSelectedServers()); },
                Category = 0
            });

            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Restart",
                Action = () => { PlugInterface.RestartServer(GetSelectedServers()); },
                Category = 0
            });

            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Autoconfigure VMHost",
                Action = () => { PlugInterface.ConfigureServer(GetSelectedServers()[0]); },
                Category = 0,
                IsVisible = () => {
                    return GetSelectedServers().Count == 1;
                }
            });

            ActionHandlers.Add(new ActionsListAction
            {
                Caption = "Autoconfigure MAC Pool",
                Action = () => { PlugInterface.SetMacRange(GetSelectedServers()[0]); },
                Category = 0,
                IsVisible = () => {
                    return GetSelectedServers().Count == 1;
                }
            });

            ActionCategories[0] = "Server Operations";
            InitializeComponent();
        }

        #endregion

        #region Events

        private void ServersList_Load(object sender, EventArgs e)
        {
#if HorribleCode
            Point destPt = new Point(8, 0);
            Size size = new Size(25 + 8, 25);
            serverView.ImageList = new ImageList();
            serverView.ItemHeight = 30;
            serverView.ImageList.ImageSize = size;
            foreach (String imgKey in imageList.Images.Keys)
            {
                Bitmap bmp = new Bitmap(size.Width, size.Height);
                Graphics g = Graphics.FromImage(bmp);
                g.InterpolationMode = InterpolationMode.NearestNeighbor;
                g.DrawImage(imageList.Images[imgKey], destPt);
                g.Dispose();
                serverView.ImageList.Images.Add(imgKey, (Image)bmp);
            }
#endif
            // Add root nodes
            rootNode = new TreeNode("All Servers", 0, 0);
            serverView.Nodes.Add(rootNode);
            distNode = new TreeNode("Distributed Network", 1, 1);
            serverView.Nodes.Add(distNode);
            distNode.Checked = true;
            rootNode.Checked = true;
            serverView.Refresh();
            distNode.Checked = false;
            rootNode.Checked = false;
            serverView.Refresh();

            RefreshList();
        }

        private void serverView_AfterCheck(object sender, TreeViewEventArgs e)
        {
            this.MarkActionDirty();
        }

        private void serverView_AutoCheck(object sender, TreeViewEventArgs e)
        {
            this.MarkActionDirty();
        }

        #endregion

        #region Public Methods

        public void AddServerChild(Server srv, bool isController = false)
        {
            TreeNode n = new TreeNode();
            n.Text = srv.HostName;
            n.Tag = srv;
            if(isController) n.NodeFont = new Font(serverView.Font, FontStyle.Bold);
            rootNode.Nodes.Add(n);
            serverView.Refresh();
        }

        public void AddServerChild(string hn, bool isController = false)
        {
            TreeNode n = new TreeNode();
            Server srv = SessionState.Instance.Controller.GetServer(hn);
            n.Text = srv.HostName;
            n.Tag = srv;
            if (isController) n.NodeFont = new Font(serverView.Font, FontStyle.Bold);
            rootNode.Nodes.Add(n);
            serverView.Refresh();
        }

        public void RefreshList()
        {
            rootNode.Nodes.Clear();
            AddServerChild(SessionState.Instance.Controller, true);
            foreach (var s in SessionState.Instance.Controller.Servers)
                AddServerChild(s);
        }

        public List<Server> GetSelectedServers()
        {
            return rootNode.Nodes.Descendants()
                    .Where(n => n.Checked)
                    .Select(n => n.Tag as Server)
                    .ToList();
        }

        #endregion
    }
}
