# Virtual Machine Manager
[![Build Status](http://PC18-126.richmondhill.local:8080/job/CI%20Pipeline/job/master/badge/icon)](http://PC18-126.richmondhill.local:8080/job/CI%20Pipeline/job/master/) &nbsp;
[![Browse Artifacts](https://img.shields.io/badge/Browse-Artifacts-lightgrey.svg)](http://pc18-126.richmondhill.local:8080/job/CI%20Pipeline/job/master/) &nbsp;
[![Download Nightly](https://img.shields.io/badge/Download-Nightly-blue.svg)](http://pc18-126.richmondhill.local:8080/job/CI%20Pipeline/job/master/lastSuccessfulBuild/artifact/trhvmgr/bin/Release/*zip*/Release.zip)

## About

This repository contains the latest sources for the proprietary Hyper-V manager written for implementation in the EBC Training Room.

## Documentation

All required knowledge, from maintenance/development to usage of the tool should be documented in the project wiki. The contents of the wiki should be preserved when migration of Gitea (the current self-hosted Git provider).

## CI Pipeline

Continuous integration is provided through our Jenkins server (runs alongside the Gitea instance). Visit the Jenkins server [here](http://pc18-126.richmondhill.local:8080/job/CI%20Pipeline/). Login with the default `gitadmin` user. The CI pipeline delivers nightly builds, however they are not deployed to the Gitea releases. Instead, the releases must be manually tagged and uploaded.

## Issue Tracking

Use the built-in Gitea issue manager to submit an issue/bug. To fix an issue (this is important), **create a pull request** to the main repository. From there, we can merge your pull request with the main branch if nothing breaks. This will prevent any commits from breaking the repository. To create a feature, **create a pull request** to the main repository, and we will approve/disapprove the request and merge it to the main branch. **However, if you are on the dev team, pull requests are not necessary.** However, they are still nice as they allow us to approve/disapprove any changes and evaluate whether they are necessary for the function of the application.
