﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using trhvmgr.Core;

namespace trhvmgr.Test
{
    class Program
    {
        static TcpClient client;
        static NetworkStream networkStream;
        static SslStream ssl;
        static BinaryReader br;
        static BinaryWriter bw;

        static bool ValidateCert(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors == SslPolicyErrors.None)
                return true;
            Console.WriteLine("Certificate error: {0}", sslPolicyErrors);
            foreach(var ch in chain.ChainStatus)
                Console.WriteLine("Status: {0} {1}", ch.Status, ch.StatusInformation);
            return true; // Allow untrusted certificates anyways.
        }

        static void Main(string[] args)
        {
            client = new TcpClient("localhost", 3141);
            Console.WriteLine("Client connected!");
            networkStream = client.GetStream();
            ssl = new SslStream(networkStream, false, new RemoteCertificateValidationCallback(ValidateCert));
            ssl.AuthenticateAsClient("localhost");
            br = new BinaryReader(ssl, Encoding.UTF8);
            bw = new BinaryWriter(ssl, Encoding.UTF8);

            // Read welcome message & authenticate
            if (br.ReadByte() == (byte) PacketTypes.MESSAGE)
                Console.WriteLine(br.ReadString());
            do
            {
                bw.Write(Console.ReadLine());
            } while (ServerUtils.GetNextRealPacketByte(br) == (byte) PacketTypes.AUTHNO);
            Console.WriteLine("Authenticated!");

            // Start responding to all client queries
            while (client.Connected)
            {
                Console.Write("> ");
                switch (Console.ReadLine())
                {
                    case "INSERT":
                        bw.Write((byte)PacketTypes.INSERT);
                        Console.Write("Name: ");
                        bw.Write(Console.ReadLine());
                        Console.Write("jsondoc: ");
                        bw.Write(Console.ReadLine());
                        break;
                    case "FIND":
                        bw.Write((byte)PacketTypes.FIND);
                        Console.Write("Name: ");
                        bw.Write(Console.ReadLine());
                        Console.Write("bsondoc: ");
                        bw.Write(Console.ReadLine());
                        ServerUtils.GetNextRealPacketByte(br);
                        int lim = br.ReadInt32();
                        for (int i = 0; i < lim; i++)
                            Console.WriteLine(br.ReadString());
                        break;
                }
            }
        }
    }
}
