﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Topology;
using System.Text;
using System.Threading.Tasks;

namespace trhvmgr.Plugs
{
    /// <summary>
    /// This class should look almost identical to the trhvmgr.Core.PlugInterface class,
    /// meaning that it should contain the same methods and signatures.
    /// </summary>
    public static class MainInterface
    {
        private static Action<string> ErrorAction;
        private static Action<string> WriteStatus;
        private static PSCredential cred;

        public static void Init(Action<string> e, Action<string> w, PSCredential c)
        {
            // TODO: Pass down PSCredentials here too instead of adding it as a parameter for each method
            ErrorAction = e;
            WriteStatus = w;
            cred = c;
        }

        #region Virtual Machine Creation/Destruction

        public static Guid CreateVm(string guid, string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            Collection<PSObject> vm;
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddStatement().AddCommand("Get-VM").AddParameter("Id", guid);
                ps.AddStatement().AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Get-VMHardDiskDrive");
                ps.AddStatement().AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Get-VMNetworkAdapter");
                var res = ps.Invoke();
                int gen = (int) res[0].Members["Generation"].Value;
                string vhd = (string)res[1].Members["Path"].Value;
                string swt = (string)res[2].Members["SwitchName"].Value;
                vm = ps.AddStatement().AddCommand("New-VM")
                    .AddParameter("Name", "Test1")
                    .AddParameter("Generation", gen)
                    .AddParameter("BootDevice", "VHD")
                    .AddParameter("SwitchName", swt)
                    .AddParameter("VHDPath", vhd)
                    .AddParameter("Force")
                    .Invoke();
            }
            return (Guid)vm[3].Members["VmId"].Value;
        }

        public static void DeleteVm(string guid, string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            Collection<PSObject> vm;
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddStatement().AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Remove-VM").AddParameter("Force");
                ps.Invoke();
            }
        }

        #endregion

        #region Virtual Machine State Control

        public static void StartVm(string guid, string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Start-VM").Invoke();
            }
        }

        public static void StopVm(string guid, string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Stop-VM").Invoke();
            }
        }

        public static void ResumeVm(string guid, string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Resume-VM").Invoke();
            }
        }

        public static void RestartVm(string guid, string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Restart-VM").Invoke();
            }
        }

        public static void SuspendVm(string guid, string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Get-VM").AddParameter("Id", guid).AddCommand("Suspend-VM").Invoke();
            }
        }

        #endregion

        #region Virtual Machine State Query

        public static List<PSObject> GetVms(string hostName)
        {
            List<PSObject> vms = new List<PSObject>();
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddStatement().AddCommand("Get-VM");
                var results = ps.Invoke();
                vms.AddRange(results);
            } // End using
            return vms;
        }

        #endregion

        #region Machine State Control

        public static void StartServer(IPAddress ip, PhysicalAddress mac)
        {
            var mask = new NetMask(255, 255, 255, 0);
            int cidr = mask.Cidr;
            var networkPrefix = ip & mask; // Bitwise and to mask the IP
            networkPrefix = ip.GetNetworkPrefix(mask);
            IPAddress broadcastAddress = ip.GetBroadcastAddress(mask);
            // Is the server online?
            PingReply reply = null;
            try
            {
                Ping ping = new Ping();
                reply = ping.Send(ip, 2000 /* timeout = 2 seconds */);
                if (reply.Status != IPStatus.Success)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        WriteStatus($"Attempting WoL {i + 1}/5...");
                        // Go, go, go!
                        new IPEndPoint(broadcastAddress, 0).SendWol(mac);
                        reply = ping.Send(ip, 10000 + i * 4); // 10 - 30 second incremental timeout
                        if (reply.Status == IPStatus.Success) break;
                        WriteStatus("WoL Successful!");
                    }
                    if (reply.Status != IPStatus.Success) throw new Exception("Host unreachable. WoL failed.");
                }
            }
            catch (Exception e) { ErrorAction(e.Message); return; }

            if (reply.Status != IPStatus.Success)
                return;
        }

        public static void RestartServer(string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Restart-Computer").AddParameter("Force").Invoke();
            }
        }

        public static void StopServer(string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Stop-Computer").AddParameter("Force").Invoke();
            }
        }

        public static void ConfigureServer(string hostName)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Set-VMHost")
                    .AddParameter("Confirm")
                    .AddParameter("EnableEnhancedSessionMode", true)
                    .AddParameter("NumaSpanningEnabled", true)
                    .AddParameter("VirtualMachinePath", @"C:\ProgramData\Microsoft\Windows\Hyper-V")
                    .AddParameter("VirtualHardDiskPath", @"C:\Users\Public\Documents\Hyper-V\Virtual Hard Disks")
                    .Invoke();
                ps.AddCommand("New-VMSwitch")
                    .AddParameter("name", "Default Bridged")
                    .AddParameter("NetAdapterName", "Ethernet")
                    .AddParameter("AllowManagementOS", true)
                    .Invoke();
            }
        }

        public static void SetMacRange(string hostName, long start, long end)
        {
            Runspace runspace = GetRunspace(cred, hostName);
            runspace.Open();
            using (PowerShell ps = PowerShell.Create())
            {
                ps.Runspace = runspace;
                ps.AddCommand("Restart-Computer")
                    .AddParameter("Confirm")
                    .AddParameter("MacAddressMaximum", start.ToString("X12"))
                    .AddParameter("MacAddressMinimum", end.ToString("X12"))
                    .Invoke();
            }
        }

        #endregion

        #region Private Credentials

        private static Runspace GetRunspace(PSCredential cred, string hostName)
        {
            WSManConnectionInfo ci = new WSManConnectionInfo();
            ci.ComputerName = hostName;
            ci.AuthenticationMechanism = AuthenticationMechanism.Kerberos;
            ci.Credential = cred;
            Runspace runspace = RunspaceFactory.CreateRunspace(ci);
            return runspace;
        }

        #endregion
    }
}
